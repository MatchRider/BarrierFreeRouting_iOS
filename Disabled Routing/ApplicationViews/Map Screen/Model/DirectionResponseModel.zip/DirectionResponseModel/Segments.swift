//
//  Segments.swift
//
//  Created by  on 20/02/18
//  Copyright (c) . All rights reserved.
//

import Foundation
import ObjectMapper

public final class Segments: Mappable, NSCoding {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let duration = "duration"
    static let steps = "steps"
    static let distance = "distance"
  }

  // MARK: Properties
  public var duration: Int?
  public var steps: [Steps]?
  public var distance: Float?

  // MARK: ObjectMapper Initializers
  /// Map a JSON object to this class using ObjectMapper.
  ///
  /// - parameter map: A mapping from ObjectMapper.
  public required init?(map: Map){

  }

  /// Map a JSON object to this class using ObjectMapper.
  ///
  /// - parameter map: A mapping from ObjectMapper.
  public func mapping(map: Map) {
    duration <- map[SerializationKeys.duration]
    steps <- map[SerializationKeys.steps]
    distance <- map[SerializationKeys.distance]
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = duration { dictionary[SerializationKeys.duration] = value }
    if let value = steps { dictionary[SerializationKeys.steps] = value.map { $0.dictionaryRepresentation() } }
    if let value = distance { dictionary[SerializationKeys.distance] = value }
    return dictionary
  }

  // MARK: NSCoding Protocol
  required public init(coder aDecoder: NSCoder) {
    self.duration = aDecoder.decodeObject(forKey: SerializationKeys.duration) as? Int
    self.steps = aDecoder.decodeObject(forKey: SerializationKeys.steps) as? [Steps]
    self.distance = aDecoder.decodeObject(forKey: SerializationKeys.distance) as? Float
  }

  public func encode(with aCoder: NSCoder) {
    aCoder.encode(duration, forKey: SerializationKeys.duration)
    aCoder.encode(steps, forKey: SerializationKeys.steps)
    aCoder.encode(distance, forKey: SerializationKeys.distance)
  }

}
