//
//  DirectionResponseModel.swift
//
//  Created by  on 20/02/18
//  Copyright (c) . All rights reserved.
//

import Foundation
import ObjectMapper

public final class DirectionResponseModel: Mappable, NSCoding {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let info = "info"
    static let bbox = "bbox"
    static let routes = "routes"
  }

  // MARK: Properties
  public var info: Info?
  public var bbox: [Double]?
  public var routes: [Routes]?

  // MARK: ObjectMapper Initializers
  /// Map a JSON object to this class using ObjectMapper.
  ///
  /// - parameter map: A mapping from ObjectMapper.
  public required init?(map: Map){

  }

  /// Map a JSON object to this class using ObjectMapper.
  ///
  /// - parameter map: A mapping from ObjectMapper.
  public func mapping(map: Map) {
    info <- map[SerializationKeys.info]
    bbox <- map[SerializationKeys.bbox]
    routes <- map[SerializationKeys.routes]
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = info { dictionary[SerializationKeys.info] = value.dictionaryRepresentation() }
    if let value = bbox { dictionary[SerializationKeys.bbox] = value }
    if let value = routes { dictionary[SerializationKeys.routes] = value.map { $0.dictionaryRepresentation() } }
    return dictionary
  }

  // MARK: NSCoding Protocol
  required public init(coder aDecoder: NSCoder) {
    self.info = aDecoder.decodeObject(forKey: SerializationKeys.info) as? Info
    self.bbox = aDecoder.decodeObject(forKey: SerializationKeys.bbox) as? [Double]
    self.routes = aDecoder.decodeObject(forKey: SerializationKeys.routes) as? [Routes]
  }

  public func encode(with aCoder: NSCoder) {
    aCoder.encode(info, forKey: SerializationKeys.info)
    aCoder.encode(bbox, forKey: SerializationKeys.bbox)
    aCoder.encode(routes, forKey: SerializationKeys.routes)
  }

}
