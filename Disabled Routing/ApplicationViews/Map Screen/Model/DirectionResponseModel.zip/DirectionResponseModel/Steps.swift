//
//  Steps.swift
//
//  Created by  on 20/02/18
//  Copyright (c) . All rights reserved.
//

import Foundation
import ObjectMapper

public final class Steps: Mappable, NSCoding {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let instruction = "instruction"
    static let name = "name"
    static let wayPoints = "way_points"
    static let type = "type"
    static let duration = "duration"
    static let distance = "distance"
  }

  // MARK: Properties
  public var instruction: String?
  public var name: String?
  public var wayPoints: [Int]?
  public var type: Int?
  public var duration: Int?
  public var distance: Int?

  // MARK: ObjectMapper Initializers
  /// Map a JSON object to this class using ObjectMapper.
  ///
  /// - parameter map: A mapping from ObjectMapper.
  public required init?(map: Map){

  }

  /// Map a JSON object to this class using ObjectMapper.
  ///
  /// - parameter map: A mapping from ObjectMapper.
  public func mapping(map: Map) {
    instruction <- map[SerializationKeys.instruction]
    name <- map[SerializationKeys.name]
    wayPoints <- map[SerializationKeys.wayPoints]
    type <- map[SerializationKeys.type]
    duration <- map[SerializationKeys.duration]
    distance <- map[SerializationKeys.distance]
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = instruction { dictionary[SerializationKeys.instruction] = value }
    if let value = name { dictionary[SerializationKeys.name] = value }
    if let value = wayPoints { dictionary[SerializationKeys.wayPoints] = value }
    if let value = type { dictionary[SerializationKeys.type] = value }
    if let value = duration { dictionary[SerializationKeys.duration] = value }
    if let value = distance { dictionary[SerializationKeys.distance] = value }
    return dictionary
  }

  // MARK: NSCoding Protocol
  required public init(coder aDecoder: NSCoder) {
    self.instruction = aDecoder.decodeObject(forKey: SerializationKeys.instruction) as? String
    self.name = aDecoder.decodeObject(forKey: SerializationKeys.name) as? String
    self.wayPoints = aDecoder.decodeObject(forKey: SerializationKeys.wayPoints) as? [Int]
    self.type = aDecoder.decodeObject(forKey: SerializationKeys.type) as? Int
    self.duration = aDecoder.decodeObject(forKey: SerializationKeys.duration) as? Int
    self.distance = aDecoder.decodeObject(forKey: SerializationKeys.distance) as? Int
  }

  public func encode(with aCoder: NSCoder) {
    aCoder.encode(instruction, forKey: SerializationKeys.instruction)
    aCoder.encode(name, forKey: SerializationKeys.name)
    aCoder.encode(wayPoints, forKey: SerializationKeys.wayPoints)
    aCoder.encode(type, forKey: SerializationKeys.type)
    aCoder.encode(duration, forKey: SerializationKeys.duration)
    aCoder.encode(distance, forKey: SerializationKeys.distance)
  }

}
